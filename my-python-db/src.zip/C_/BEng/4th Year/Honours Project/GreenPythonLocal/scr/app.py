def helloWorld(): 
    print("helloWorld!")

def goodbye():
    print("goodbye!")
    